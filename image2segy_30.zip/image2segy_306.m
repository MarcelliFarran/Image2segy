% IMAGE2SEGY:  Converts Raster to SEG-Y format. 
% Marcel�l� Farran, ICM,CSIC Barcelona, mfarran@icm.csic.es
% Program page: http://gma.icm.csic.es/node/67 
%_________________________________________________________________________
% SegyMAT ((C)2017 Thomas Mejer Hansen) package must be in your Matlab Path
% Latest version here: http://segymat.sourceforge.net/
  

clear all; close all; 
This_version='3.0.6'; SegymatVersion;
disp 'IMAGE2SEGY v3.0.6, 1/XII/2017: SEISMIC PROFILES IMAGES TO SEGY FILE';
defans={'G82'; '81'; '1'; '1'; '2017'; '0'; 'ICM';'0'}; %Defaults

%{    
Default values: (defans=....)
Survey;LineName;Day;Month;Year;Offset;Company;TimeLines cleaning factor 0-4)
This line can (should) be changed
Other values as Company , Area,  etc. etc. can be
fixed in the ASCII-EBCDIC Header Form (line 520 aprox of this script)      
__________________________________________________________________________


                *****  NEW in version 3  *****
Compatible MATLAB & OCTAVE
Time lines removal for gray scale images.
Select a value between 1 and 4 ( 0: no removal).
Better results with 2 or 3.   
Unexpected results can be produced in images with many horizontal reflectors.

                       

                   H E L P  ( READ ME)
__________________________________________________________________________
 RASTER IMAGE can be a BMP, JPG or TIFF (color & gray scale)                                    
_________________________________________________________________________ 
IF seismic profile has only positive or negative values as old
 high resolution seismics on analogic recorders then save the
 image as 8 BITS Gray-scale file. If profile is a Blue-white-Red 
 record then input file should be a RGB file
 For old multichannel wiggle profiles better if save as Gray scale
 image  Scanner resolutions between 150 and 200 dpi are enough. 


Program will ask you to input a parameters file (can be obviated
IF YOU DO NOT NEED a georeferences, or time scaled segy), 
an image file and a output segy file.


PARAMETER FILE FORMAT:__________________________________________________
ASCII file with comma separated values with this 6 columns structure:

PARAMETERS HEADER______________________________________________________

TEXT FILE FIRST LINE FORMAT
TLP, L, ML, REV, DSF, ZUTM
where:

TLP = Trace length in pixels (constant along the whole profile, integer) 
L =  LineNumber (integer) that will be used only in the binary header, in the
   text header you can use line names as CAB-001L-N. In the binary header 
   you can only put there 1 for this line name. 
   You can use 0 for all lines without problem. 
   The program will alk you for the real name of the lines.
ML =  0  ->  Marine profile 
      1  ->  Land profile with datum over sea level ( see ** downward) 
REV = 0  ->  Segy Revision 0
      1* ->  Segy Revision 1  ( *recommeded)
DSF =  1,3 or 5 
       1  ->  32 bits IBM floating point 
       3* ->  16 bits IBM floating point ( *recomended, smaller output files)
       5  ->  IEEE format
ZUTM = zone UTM integer (1-60) 


Exemple: 2880,22,0,1,3,31  
  a trace length of 2880 pixels, line ID 22, marine survey, stored in segy
  revision 1 and IBM format 16 bits and given coordinates of UTM zone 31 

PARAMETERS REFERENCE LINES______________________________________________
after the header add as lines as you like with this structure (integers
also)

px, py, X1, Y1, TD, TL


px & py -> Are top first pixels position for any known (or not)
          position in the image profile.

X1 & Y1 -> are UTM position in meters for known positions. 
         Put zeros if unknown but you want use this position to correct 
         distortion  in the image due to paper drift in the scanner device.  

TD -> For Marine profiles is the delay (positive) of the interval in ms  
      (positive values in byte 105 and 109 in the output SEGY).
       For Land profiles is the time over the datum (negative 
       value in the byte 105 and 0 in the byte 109).  

TL -> (Constant in whole profile)is the time interval or trace length in ms.
      For Land profiles the full time including time over datum.
     (see example included in the downloaded zip).


For any changes (speed, course, delay) in the profile or just to get better
               position control you can add a new line in the control file.
Lines with 0 in utm X and Y can be used to correct the paper drift in the
               scanner ( real world positions are interpolated).
Example files included in the downloaded ZIP file 

example without zeros in positions
2880,100,0,1,3,31
1,   22,555000,4500000,2400,1000
1143,23,557000,4502000,2200,1000
2000,24,558000,4503000,2200,1000
2701,22,559000,4504000,2200,1000

example with zeros in positions included to correct distortion of the image.
2880,100,0,1,3,31
1,   22,555000,4500000,2400,1000
1143,23,557000,4502000,2200,1000
2000,24,      0,     0,2200,1000   
2701,22,559000,4504000,2200,1000

Land_example
1141,001,1,1,3,30
61,42,500000,4500000,600,5600
1392,42,505000,4505000,600,5600

Program will displays a map to check possible error in the positions in then input file.

Navigation files can be obviated IF YOU DO NOT NEED a georeferences segy
with correct time scales, output willbe 1 second segy with as 
traces as pixels wide has the image and as traces samples as pixels high is
the image. Just press "cancel" when programs ask you for the parameters file.

                               --**--
%}


%______________________________ DATA PROMPT

prompt={'SURVEY NAME: (you can modifie default values in the 1rst line of the script)',...
    'SURVEY LINE:','Survey Date  DAY: (1-31)','MONTH: (1-12)',...
    'YEAR:(4 digits)', 'First Trace OFFSET','INSTUTION/COMPANY','TIMELINES REMOVAL [0-4], No Removal:0, Recomended:3'};
Title='SEG-Y ASCII HEADERS INFO & Timelines Removal';
lines=[1,70;1,30;1,30;1,30;1,30;1,30;1,30;1,30;]; 
answer=inputdlg(prompt,Title,lines,defans);
assignin('base','surname',answer{1}); assignin('base','surline',answer{2});
assignin('base','surday',answer{3}); assignin('base','surmon',answer{4});
assignin('base','suryea',answer{5}); assignin('base','trazoff',answer{6});
% This last value is used only when profile is too long and two or more
% segy are created. In case of two segy, offset in second file should be 
% the last pixel of previous section+ 1. 
assignin('base','COMPANY',answer{7});
assignin('base','Tf',answer{8});
Tf=str2num(char(Tf)); %#ok<*ST2NM>

% _______________________________________ GRAPHIC FILE INPUT

[infile, pathname]=uigetfile( ...
{'*.tif;*.bmp;*.jpg;','Graphics formats : (*.bmp,*.jpg,*.tif)';
    '*.*',  'All (*.*)'},'IMAGE2SEGY: Scanned Seismic File' );
infileGraf=[pathname infile]; 
Ginfile=infile;
RawSeisdata=imread(infileGraf);
[raws,cols,colores]=size(RawSeisdata);
samples=raws;
if colores==1
        button=questdlg('�How is the image?','IMAGE FORMAT','B&W/Gray Scale',...
        'Colors Scale','B&W/Gray Scale');
else    % colores = 3  
        button=questdlg('�How is the image?','IMAGE FORMAT','B&W/Gray Scale',...
        'Colors Scale','Colors Scale');  
         rgb = [ ...
     0      0   1.00     
  0.06   0.06   1.00 
  0.13   0.13   1.00     
  0.19   0.19   1.00 
  0.26   0.26   1.00     
  0.32   0.32   1.00 
  0.39   0.39   1.00     
  0.45   0.45   1.00 
  0.52   0.52   1.00     
  0.58   0.58   1.00 
  0.65   0.65   1.00    
  0.71   0.71   1.00 
  0.77   0.77   1.00     
  0.84   0.84   1.00
  0.90   0.90   1.00     
  1.00   1.00   1.00 
  1.00   0.97   0.97     
  1.00   0.90   0.90 
  1.00   0.84   0.84     
  1.00   0.77   0.77 
  1.00   0.71   0.71     
  1.00   0.65   0.65 
  1.00   0.58   0.58     
  1.00   0.52   0.52 
  1.00   0.45   0.45     
  1.00   0.32   0.32 
  1.00   0.26   0.26     
  1.00   0.19   0.19 
  1.00   0.13   0.13     
  1.00   0.06   0.06 
  1.00      0      0];
end    
%____________________________________  Parameters file 
[infile,pathname]=uigetfile( ...
{'*.txt;*.dat;*.csv','Text files : (*.txt,*.dat,*.csv)';
    '*.*', 'All (*.*)'},'IMAGE2SEGY: Control file (if cancel, segy is created w/o nav & delays ');
Ninfile=infile;
infile=[pathname infile];
if Ninfile == 0 
    XL=cols; YL=raws;     
    CTR = [YL,1,0,1,3,31
          1,1,1,1,0,1000
          XL,1,1000,1000,0,1000];
    NONAV=1;
    Ninfile='';
else
    CTR=double(uint32(load(infile)));
    NONAV=0;
end
%______________________________ Read parameters

A=size(CTR);
CTR1=CTR(1,:);   % header line
TL=CTR1(1);      %Trace length in pixels = firts value in firts line
linea=CTR1(2);   %line number (integer) to be included in segyheader ,2nd value
SeaLand=CTR1(3); % 0: Marine  1:Terrestrial profile Time 0 below the trace  origin
Revision=CTR1(4);% 0-1                 
DSF=CTR1(5);     % 1-3-5                
UTMZ=CTR1(6);    % 1-60                 
disp('___________________________________');
disp('Digitized Positions: ');
CTR2=CTR(2:size(CTR),:);         % digitized points
disp(CTR2);
name = 'Trace length';
str = [name, ' = ', num2str(TL), ' msec.'];disp (str);
name = 'Line Number';
str = [name, ' = ', num2str(linea)];disp (str);
name = 'Marine(0) or Land(1) Survey:';
str = [name, ' = ', num2str(SeaLand)];disp (str);
name = 'SEG-Y Revision';
str = [name, ' = ', num2str(Revision)];disp (str);
name = 'SEG-Y Data Sample Format (DSF)';
str = [name, ' = ', num2str(DSF)];disp (str);
name = 'Zone UTM';
str = [name, ' = ', num2str(UTMZ)];disp (str);


%________________________________________________________  Output SEGY
[SGY_outfile,pathname]=uiputfile( ...
{'*.sgy;*.seg','Format SEG-Y (*.sgy,*.seg)';
    '*.*',  'all (*.*)'}, ...
    'IMAGE2SEGY Output: SEG-Y IBM Flotant file format');
outfile=[pathname SGY_outfile];
  
%_____________________________________________________ SCALE COLOR Values 
if colores==1, colormap(gray);  cscale=gray;
else  colormap(rgb);  cscale=rgb;
end
if strcmp(button,'B&W/Gray Scale');
        disp('Grayscale selected');   
        RawSeisdata=int16(RawSeisdata);    
        RawSeisdata= 126 - RawSeisdata ;
else    
      disp('Colors scale selected');
        if colores==1 
            RawSeisdata=int16(RawSeisdata);    
            RawSeisdata= 126 - RawSeisdata ;
        else        
          CR =  double(RawSeisdata(:,:,1));
          CG =  double(RawSeisdata(:,:,2));
          CB =  double(RawSeisdata(:,:,3));
          CT =  ( CR + CG + CB ) / 3;
          RawSeisdata = 80 * ((CR ./ CT) - (CB ./ CT)) ;
        end
end
%______________________________    POSITION and SHOT for Each Pixel

disp '....Interpolating Positions.....';

pts=A(1)-1;                       % number of given positions,    
PTX=CTR2(:,1);                    % pixels X = list of x pixel values
PTY=CTR2(:,2);                    % pixels Y = idem Y
for i=1:pts;
   if PTX(i)<=0 , PTX(i)=1 ; end; % negative and 0 values = 1rst pixel
   if PTY(i)<=0 , PTY(i)=1 ; end;  
end;
TI=CTR2(:,5);         % Trace start ms,                column 5
TT=CTR2(2,6);         % trace length in ms (Constant)  column 6
X=CTR2(:,3);          % X UTM list ,                   column 3
Y=CTR2(:,4);          % Y UTM list ,                   column 4
%min and max distance between georeferenced points.
dissize=size(X,1)-1;
for i=1:(size(X)-1);
    distance(i)=sqrt(((X(i)-X(i+1))^2)+((Y(i)-Y(i+1))^2));  
end;
mdist=uint32(min(distance));
Mdist=uint32(max(distance));
mdist = num2str(mdist);
Mdist = num2str(Mdist);
RealShots=PTX(pts)-PTX(1)+1;   % valid shots = interval between 1 and last digitized +1 
CTR2(pts,1)=RealShots;  
RawSeisdata = (RawSeisdata (:,PTX(1):PTX(pts)));  %resize array          
j=0;
for i=1:pts;  
   if X(i)~=0 
        j=j+1; 
        PTXNZ(j)=PTX(i);            % pixel with real position
        XNZ(j)=X(i);                % real world position
        PTYNZ(j)=PTY(i);
        YNZ(j)=Y(i);
    end;
end;
for i=PTX(1):PTX(pts);                           
    Hcorr(i-PTX(1)+1)=int16(interp1(PTX,PTY,i));     % interpol. Y pixel for scanner drift correction 
    UTMX(i-PTX(1)+1)=int32(interp1(PTXNZ,XNZ,i));    % interpol. X position between field positions
    UTMY(i-PTX(1)+1)=int32(interp1(PTXNZ,YNZ,i));    % interpol. Y position "              "
end
seisdata=zeros(TL,RealShots);   
vsize = samples;
samples = TL;
dt = int16((1000*TT/TL));        %sampling rate in microsec in the segy   
name = 'SEG-Y Sampling Rate';
str = [name, ' = ', num2str(dt),' microsec'];disp (str);


for i=1:RealShots;
    Hinit=Hcorr(i);
    Hend=Hinit+TL-1;    
    if Hend > vsize; Hend=vsize;   end;
    ThisTrace=RawSeisdata(Hinit:Hend,i);
    j=Hend-Hinit+1;
    seisdata(1:j,i)=ThisTrace;
end;
clear RawSeisdata;

%_________________________________________Timelines removal

switch Tf
   case 0,      Td=255;
   case 1,      Td=50;
   case 2,      Td=30;
   case 3,      Td=20;
   case 4,      Td=10;
    otherwise,  Td=255;  Tf=0;
end
if Tf > 0 
         j=1; ii=0;
         for i=1000:1000:RealShots
             sdata=seisdata(:,j:i); 
             ii=ii+1;
             sumat(:,ii) =sum(sdata,2);
             j=i+1;
         end
        sumat = sumat/1000;
        v=size(sumat,1);
        h=size(sumat,2);
        medmov= zeros(v,h);
        pico= zeros(v,h);
        Mdif= zeros(v,h); %#ok<*NASGU>
         for i=1:1:h
             for j=10:1:v-9
                medmov(j,i) = sumat(j-9,i)+  sumat(j-8,i)+ sumat(j-7,i)+ sumat(j-6,i)+ sumat(j-5,i)+...
                    sumat(j-4,i)+ sumat(j-3,i)+  sumat(j-2,i)+ sumat(j-1,i)+ sumat(j,i)  + sumat(j+1,i)+ sumat(j+2,i)+ ...
                    sumat(j+3,i)+ sumat(j+4,i)+  sumat(j+5,i)+ sumat(j+6,i)+ sumat(j+7,i)+ sumat(j+8,i)+ sumat(j+9,i); 
                medmov(j,i)=medmov(j,i) /19;  
             end;
         end;
         Mdif = sumat - medmov;

         for i=1:1:h
            for j=2:1:v-1
                if Mdif(j,i) >= Td && Mdif(j,i) > Mdif(j+1,i) &&  Mdif(j,i) > Mdif(j-1,i)
                    pico(j,i)=1;
                else
                    pico(j,i)=0; 
                end
            end
         end
         sdata=seisdata;
         for j=1:1:cols
            for i=6:1:v-6
                ii= ceil(j/1000);
                if ii <= h
                    if pico(i,ii)==1 
                       % sdata(i-2,j)=((3*sdata(i-4,j))+(1*sdata(i+4,j)))/4;
                        sdata(i-1,j)=((2*sdata(i-3,j))+(1*sdata(i+3,j)))/3;
                        sdata(i,j)  =((1*sdata(i-3,j))+(1*sdata(i+3,j)))/2;
                        sdata(i+1,j)=((1*sdata(i-3,j))+(2*sdata(i+3,j)))/3;
                       % sdata(i+2,j)=((1*sdata(i-4,j))+(3*sdata(i+4,j)))/4;
                    end
                end    
            end
         end
         seisdata = sdata;
end
 %_____________________________________   PROFILE DISPLAY

fig1=figure(1);
scrsz = get(0,'ScreenSize');
set(fig1,'OuterPosition',[50 scrsz(4)/4 scrsz(4) scrsz(4)/2])
fig1=imagesc(-seisdata); 
colormap(cscale);
colorbar;
hold on;
for i=1:1:size(PTX) 
    x(1)=PTX(i)-PTX(1)+1;  y(1)=1;
    x(2)=PTX(i)-PTX(1)+1;  y(2)=samples;
    if x(1)==1, x(1)=10;end
    if x(2)==1, x(2)=10;end    
    fig1=plot(x,y,'r','LineWidth',2);
    cartel=[num2str(i),'  X: ', num2str(X(i)),' Y: ' ,num2str(Y(i)),...
        ' Top: ', num2str(TI(i)),'  Bottom: ', num2str(TI(i)+TT), ' msec    ']; 
    ks=['\fontsize{8}' cartel];
    text(x(1)+10,y(1)+10,ks,'Rotation',270,'BackgroundColor',[.7 .9 .7]);
end

format
delay=zeros(pts,1);
for i=PTX(1):PTX(pts);    
    for p=1:pts;
        if PTX(p)<=i;
          delay(i+1-PTX(1))=TI(p);  
        end;
    end;
end;
% _____________________________________ MAP display
i=0;j=0;
fig2=figure(2);
set(fig2,'OuterPosition',[scrsz(3)/1.7 scrsz(3)/4 scrsz(3)/4 scrsz(3)/4])
    for i=1:1:size(X,1)
       if X(i) ~= 0
           j=j+1; XF(j)= X(i); YF(j)= Y(i); 
       end
    end
axis([min(XF)-2500 ,max(XF)+2500,min(YF)-2500,max(YF)+2500]);
plot(XF,YF,'-bs','LineWidth',1,...         
    'MarkerEdgeColor','b','MarkerFaceColor','r','MarkerSize',4);
for i=1:size(X,1);
    hold on;
    cartel= num2str(i);
    ks=['\fontsize{10}' cartel];
    if X(i) ~= 0, text(X(i),Y(i),ks,'BackgroundColor',[.7 .9 .7]);end
end
set(gca, 'YTickMode','manual')
set(gca, 'YTickLabel',num2str(get(gca,'YTick')'))
set(gca, 'XTickMode','manual')
set(gca, 'XTickLabel',num2str(get(gca,'XTick')'))
set(gca,'XGrid','on','YGrid','on','FontSize',8);
xlab=strcat('UTM ZONE: ',num2str(UTMZ)); xlabel(xlab);
hleg = legend(SGY_outfile,'Location','NorthEastOutside');
set(hleg,'FontAngle','italic','TextColor',[.3 .2 .1]); 
drawnow;
hold off;

%_________________________________________     ASCII_EBCDIC convert

SegyHeader.TextualFileHeader=sprintf('%3200s','SEGY READER');
SegyHeader.SegyFormatRevisionNumber = Revision;
ebcdic_arr=[
    '00';'01';'02';'03';'04';'05';'06';'07';'08';'09';'0A';'0B';'0C';'0D';
    '0E';'0F';'10';'11';'12';'13';'14';'15';'16';'17';'18';'19';'1A';'1B';
    '1C';'1D';'1E';'1F';'20';'21';'22';'23';'24';'25';'26';'27';'28';'29';
    '2A';'2B';'2C';'2D';'2E';'2F';'30';'31';'32';'33';'34';'35';'36';'37';
    '38';'39';'3A';'3B';'3C';'3D';'3E';'3F';'40';'4A';'4B';'4C';'4D';'4E';
    '4F';'50';'5A';'5B';'5C';'5D';'5E';'5F';'60';'61';'6A';'6B';'6C';'6D';
    '6E';'6F';'79';'7A';'7B';'7C';'7D';'7E';'7F';'81';'82';'83';'84';'85';
    '86';'87';'88';'89';'91';'92';'93';'94';'95';'96';'97';'98';'99';'A1';
    'A2';'A3';'A4';'A5';'A6';'A7';'A8';'A9';'C0';'C1';'C2';'C3';'C4';'C5';
    'C6';'C7';'C8';'C9';'D0';'D1';'D2';'D3';'D4';'D5';'D6';'D7';'D8';'D9';
    'E0';'E2';'E3';'E4';'E5';'E6';'E7';'E8';'E9';'F0';'F1';'F2';'F3';'F4';
    'F5';'F6';'F7';'F8';'F9';'FF';'00';'01';'02';'03';'37';'2D';'2E';'2F';
    '2F';'16';'05';'25';'0B';'0C';'0D';'10';'11';'12';'13';'3C';'3D';'32';
    '26';'18';'3F';'27';'1C';'1D';'1D';'1E';'1F';'07';'40';'5A';'7F';'7B';
    '5B';'6C';'50';'7D';'4D';'5D';'5C';'4E';'6B';'60';'4B';'61';'F0';'F1';
    'F2';'F3';'F4';'F5';'F6';'F7';'F8';'F9';'7A';'5E';'4C';'7E';'6E';'6F';
    '7C';'00';'E0';'00';'00';'6D';'79';'C0';'4F';'D0';'A1'];
ascii_arr=[
    '00';'01';'02';'03';'9C';'09';'86';'7F';'97';'8D';'8E';'0B';'0C';'0D';
    '0E';'0F';'10';'11';'12';'13';'9D';'85';'08';'87';'18';'19';'92';'8F';
    '1C';'1D';'1E';'1F';'80';'81';'82';'83';'84';'0A';'17';'1B';'88';'89';
    '8A';'8B';'8C';'05';'06';'07';'90';'91';'16';'93';'94';'95';'96';'04';
    '98';'99';'9A';'9B';'14';'15';'9E';'1A';'20';'A2';'2E';'3C';'28';'2B';
    '7C';'26';'21';'24';'2A';'29';'3B';'AC';'2D';'2F';'A6';'2C';'25';'5F';
    '3E';'3F';'60';'3A';'23';'40';'27';'3D';'22';'61';'62';'63';'64';'65';
    '66';'67';'68';'69';'6A';'6B';'6C';'6D';'6E';'6F';'70';'71';'72';'7E';
    '73';'74';'75';'76';'77';'78';'79';'7A';'7B';'41';'42';'43';'44';'45';
    '46';'47';'48';'49';'7D';'4A';'4B';'4C';'4D';'4E';'4F';'50';'51';'52';
    '5C';'53';'54';'55';'56';'57';'58';'59';'5A';'30';'31';'32';'33';'34';
    '35';'36';'37';'38';'39';'9F';'00';'01';'02';'03';'04';'05';'06';'07';
    '07';'08';'09';'0A';'0B';'0C';'0D';'10';'11';'12';'13';'14';'15';'16';
    '17';'18';'1A';'1B';'1C';'1D';'1D';'1E';'1F';'7F';'20';'21';'22';'23';
    '24';'25';'26';'27';'28';'29';'2A';'2B';'2C';'2D';'2E';'2F';'30';'31';
    '32';'33';'34';'35';'36';'37';'38';'39';'3A';'3B';'3C';'3D';'3E';'3F';
    '40';'5B';'5C';'5D';'5E';'5F';'60';'7B';'7C';'7D';'7E'];
ascii_dec_array=hex2dec(ascii_arr);
ebcdic_dec_array=hex2dec(ebcdic_arr);

%___________________________________________________________ WRITE HEADER      
disp 'IMAGE2SEGY: Creating SEG-Y file.......'

%________________ ASCII-EBCDIC Header 80 characters  
% you can add information in these lines but you can not add lines or make
% it longer than 80 characters. Use always CAPITAL Characters.
% Is very recomended to use MONOESPACED FONT to display this editor window
% If you plan to change something in this ASCII-EBCDIC header
cc00='00000000011111111112222222222333333333344444444445555555555666666666677777777778'; %80 characters rule 
%cc02='C 2 LINE              AREA                        MAP ID                       ';  
cc03='C 3 REEL NO           DAY-START OF REEL     YEAR      OBSERVER                  ';
cc04='C 4 INSTRUMENT:          MODEL               SERIAL NO                          ';
cc05='C 5 DATA TRACES/RECORD        AUXILIARY TRACES/RECORD             CDP FOLD      ';
cc06='C 6 SAMPLE INTERVAL           SAMPLES/TRACE      BITS/IN         BYTES/SAMPLE   ';
cc07='C 7 RECORDING FORMAT        FORMAT THIS REEL        MEASUREMENT SYSTEM METER    ';
cc08='C 8 SAMPLE CODE: FLOATING PT YES FIXED PT NO  FIXED PT-GAIN NO  CORRELATED NO   ';
cc09='C 9 GAIN  TYPE: FIXED YES BINARY NO  FLOATING POINT NO  OTHER NO                ';
cc10='C10 FILTERS: ALIAS     HZ  NOTCH     HZ  BAND     -     HZ  SLOPE    -  DB/OCT  ';
cc11='C11 SOURCE: TYPE            NUMBER/POINT           POINT INTERVAL               ';
cc12='C12 PATTERN:                           LENGTH        WIDTH                      ';
cc13='C13 SWEEP: START     HZ  END     HZ  LENGTH      MS  CHANNEL NO     TYPE        ';
cc14='C14 TAPER: START LENGTH       MS  END LENGTH       MS  TYPE                     ';
cc15='C15 SPREAD: OFFSET        MAX DISTANCE        GROUP INTERVAL                    ';
cc16='C16 GEOPHONES: PER GROUP     SPACING     FREQUENCY     MFG          MODEL       ';
cc17='C17 PATTERN:                           LENGTH        WIDTH                      ';
cc18='C18 TRACES SORTED BY: RECORD                                                    ';
cc19='C19 AMPLITUDE RECOVERY: NONE                                                    ';
cc21='C21 PROCESSING:                                                                 ';
cc22='C22 GENERATED FROM SCANNED FILM OR PAPER RECORD                                 ';
cc23='C23                                                                             ';       
cc28='C28 MIN. AND MAX. DISTANCE BETWEEN GEOREFERENCED TRACES:                        ';
cc30='C30                                                                             ';
cc31='C31                                                                             '; 
cc33='C33 SEGYMAT(C) 2001-2017 THOMAS MEJER HANSEN, http://segymat.sourceforge.net    '; 
cc34='C34 IMAGE2SEGY 2006-2017 M.FARRAN (ICM-CSIC)  http://www.icm.csic.es/gma        ';
cc35='C35                                                                             ';
cc36='C36                                                                             ';
cc37='C37                                                                             ';
cc38='C38                                                                             ';
cc39='C39                                                                             ';
cc40='C40 END TEXT HEADER                                                             ';
%===='00000000011111111112222222222333333333344444444445555555555666666666677777777778';
AA=strcat('C 1 COMPANY/INSTITUTION__:',upper(COMPANY));
CC={AA cc00};CCC=char(CC);cc01=CCC(1,:);
AA=strcat('C 2 LINE:__',surline,'    DATE:__',surday,'/',surmon,'/',suryea);
CC={AA cc00};CCC=char(CC);cc02=CCC(1,:);
AA=strcat('C20 MAP PROJ.:_UTM  COORD.UNITS:_METERS  ZONE ID:_',num2str(UTMZ));
CC={AA cc00};CCC=char(CC);cc20=CCC(1,:);
AA=strcat('C24 NAVIGATION FILE:__',upper(Ninfile));
CC={AA cc00};CCC=char(CC);cc24=CCC(1,:);
AA=strcat('C25 GRAPHIC FILE:__',upper(Ginfile));
CC={AA cc00};CCC=char(CC);cc25=CCC(1,:);
AA=strcat('C26 SEGY FILE:__',upper(SGY_outfile));
CC={AA cc00};CCC=char(CC);cc26=CCC(1,:);
AA=strcat('C27 SURVEY NAME:__',upper(surname),' / SURVEY LINE:__',surline);
CC={AA cc00};CCC=char(CC);cc27=CCC(1,:);
AA=strcat('C29 _',mdist,' METERS,  _',Mdist,' METERS ');
CC={AA cc00};CCC=char(CC);cc29=CCC(1,:);
AA=strcat('C32 CREATED WITH IMAGE2SEGY version:_' ,This_version, '   AND SEGYMAT');
CC={AA cc00};CCC=char(CC);cc32=CCC(1,:); 
ascii=[cc01 cc02 cc03 cc04 cc05 cc06 cc07 cc08 cc09 cc10 cc11 cc12 cc13 cc14 ...
  cc15 cc16 cc17 cc18 cc19 cc20 cc21 cc22 cc23 cc24 cc25 cc26 cc27 cc28 cc29 ... 
  cc30 cc31 cc32 cc33 cc34 cc35 cc36 cc37 cc38 cc39 cc40];
for i=1:length(ascii);
  m=find(ascii_dec_array==ascii(i));
  if length(m)>1;
    m=m(1);
  end;
  if isempty(m); 
    ebcdic(i)=0;
  else
    ebcdic(i)=(ebcdic_dec_array(m));  
  end;
end;
SegyHeader.TextualFileHeader=sprintf('%3200s',char(ebcdic));
SegyHeader.ns=samples; 
SegyHeader.dt=dt;
SegyHeader.DataTracePerEnsemble=1;
SegyHeader.Line=linea;
SegyHeader.MeasurementSystem=1;
NA=0;
%________________________________________________________  WRITE TRACES 
suryea=str2double(suryea);
surmon=str2double(surmon);
surday=str2double(surday);
k=str2double(trazoff);
if suryea==0;
    da=clock;% use today values 
else
    da=cell2mat({suryea;surmon;surday;0;0;0});
end; 
Year=da(1);
DayOfYear=datenum(0,da(2),da(3));
% actual time (H,M,S) for trace headers used (da=clock)
PTX=PTX-PTX(1)+1;

for j=1:RealShots;
    GX=0; GY=0; last=size(PTX,1);
    for t=1:last;
      if j==PTX(t); GX=CTR2(t,3); GY=CTR2(t,4); end    
      if GX ~=0; L=1; else L=0; end 
      T=j+k;
    end;
  % fprintf(fidnav,'%d,%d,%d,%8.1f,%8.1f \n',T,L,1,UTMX(j),UTMY(j));
    if (j/1000)==round(j/1000),
      SegymatVerbose(['Image2SegY: Writing Headers ',num2str(j),' of ',num2str(RealShots)])
    end
    SegyTraceHeader(j).TraceSequenceLine=T; %#ok<*SAGROW>
	SegyTraceHeader(j).TraceSequenceFile=j;
	SegyTraceHeader(j).FieldRecord=j; 
	SegyTraceHeader(j).TraceNumber=1;
	SegyTraceHeader(j).EnergySourcePoint=j;
	SegyTraceHeader(j).cdp=j;
	SegyTraceHeader(j).cdpTrace=NA;
	SegyTraceHeader(j).TraceIdenitifactionCode=1;
	SegyTraceHeader(j).NSummedTraces=NA;
	SegyTraceHeader(j).NStackedTraces=NA;
	SegyTraceHeader(j).DataUse=NA;
	SegyTraceHeader(j).offset=NA;
	SegyTraceHeader(j).ReceiverGroupElevation=NA;
	SegyTraceHeader(j).SourceSurfaceElevation=NA;
	SegyTraceHeader(j).SourceDepth=NA;
	SegyTraceHeader(j).ReceiverDatumElevation=NA;
	SegyTraceHeader(j).SourceDatumElevation=NA;
	SegyTraceHeader(j).SourceWaterDepth=NA;
	SegyTraceHeader(j).GroupWaterDepth=NA;
	SegyTraceHeader(j).ElevationScalar=NA;
	SegyTraceHeader(j).SourceGroupScalar=1; 
	SegyTraceHeader(j).SourceX=UTMX(j);    %Interpolated & given positions
	SegyTraceHeader(j).SourceY=UTMY(j);    %Interpolated & given positions 
	SegyTraceHeader(j).GroupX=GX;    % Given positions only
	SegyTraceHeader(j).GroupY=GY;    % will be zero for interpolated positions        
	SegyTraceHeader(j).CoordinateUnits=1;       % meters
	SegyTraceHeader(j).WeatheringVelocity=NA;
	SegyTraceHeader(j).SubWeatheringVelocity=NA;
	SegyTraceHeader(j).SourceUpholeTime=NA;
	SegyTraceHeader(j).GroupUpholeTime=NA;
	SegyTraceHeader(j).SourceStaticCorrection=NA;
	SegyTraceHeader(j).GroupStaticCorrection=NA;
	SegyTraceHeader(j).TotalStaticApplied=NA;
    if SeaLand==1;  delay(j)=-delay(j) ; end;
    SegyTraceHeader(j).LagTimeA=delay(j);   %Land profiles Lagtime negative
	SegyTraceHeader(j).LagTimeB=NA;
	if SeaLand==1; delay(j)=0; end; 
    SegyTraceHeader(j).DelayRecordingTime=delay(j); %Land profiles delay = 0
	SegyTraceHeader(j).MuteTimeStart=NA;
	SegyTraceHeader(j).MuteTimeEND=NA;
	SegyTraceHeader(j).ns=samples;
	SegyTraceHeader(j).dt=dt;
	SegyTraceHeader(j).GainType=NA;
	SegyTraceHeader(j).InstrumentGainConstant=NA;
	SegyTraceHeader(j).InstrumentInitialGain=NA;
	SegyTraceHeader(j).Correlated=NA;
	SegyTraceHeader(j).SweepFrequenceStart=NA;
	SegyTraceHeader(j).SweepFrequence=NA;
	SegyTraceHeader(j).SweepLength=NA;
	SegyTraceHeader(j).SweepType=NA;
	SegyTraceHeader(j).SweepTraceTaperLengthStart=NA;
	SegyTraceHeader(j).SweepTraceTaperLengthEnd=NA;
	SegyTraceHeader(j).SweepFrequenceEnd=NA;
	SegyTraceHeader(j).SweepTraceTaperLength=NA;
	SegyTraceHeader(j).TaperType=NA;
	SegyTraceHeader(j).AliasFilterFrequency=NA;
	SegyTraceHeader(j).AliasFilterSlope=NA;
	SegyTraceHeader(j).NotchFilterFrequency=NA;
	SegyTraceHeader(j).NotchFilterSlope=NA;
	SegyTraceHeader(j).LowCutFrequency=NA;
	SegyTraceHeader(j).HighCutFrequency=NA;
	SegyTraceHeader(j).LowCutSlope=NA;
	SegyTraceHeader(j).HighCutSlope=NA;   
	SegyTraceHeader(j).YearDataRecorded=Year;
	SegyTraceHeader(j).DayOfYear=DayOfYear;
    SegyTraceHeader(j).HourOfDay=NA;
	SegyTraceHeader(j).MinuteOfHour=NA;
	SegyTraceHeader(j).SecondOfMinute=NA;
	SegyTraceHeader(j).TimeBaseCode=NA;
	SegyTraceHeader(j).TraceWeightningFactor=NA;
	SegyTraceHeader(j).GeophoneGroupNumberRoll1=NA;
	SegyTraceHeader(j).GeophoneGroupNumberFirstTraceOrigField=NA;
	SegyTraceHeader(j).GeophoneGroupNumberLastTraceOrigField=NA;
	SegyTraceHeader(j).GapSize=NA;
	SegyTraceHeader(j).OverTravel=NA;
	SegyTraceHeader(j).cdpX=NA;
	SegyTraceHeader(j).cdpY=NA;
	SegyTraceHeader(j).Inline3D=NA;
	SegyTraceHeader(j).Crossline3D=NA;
	SegyTraceHeader(j).ShotPoint=j;
	SegyTraceHeader(j).ShotPointScalar=1;
	SegyTraceHeader(j).TraceValueMeasurementUnit=NA;
	SegyTraceHeader(j).TransductionConstantMantissa=NA;
	SegyTraceHeader(j).TransductionConstantPower=NA;
	SegyTraceHeader(j).TransductionUnit=NA;
	SegyTraceHeader(j).TraceIdentifier=NA;
	SegyTraceHeader(j).ScalarTraceHeader=NA;
	SegyTraceHeader(j).SourceType=NA;
    SegyTraceHeader(j).SourceEnergyDirectionMantissa=NA;
    SegyTraceHeader(j).SourceEnergyDirectionExponent=NA;
    SegyTraceHeader(j).SourceMeasurementMantissa=NA;
    SegyTraceHeader(j).SourceMeasurementExponent=NA;
    SegyTraceHeader(j).SourceMeasurementUnit=NA;
    SegyTraceHeader(j).UnassignedInt1=NA;
    SegyTraceHeader(j).UnassignedInt2=NA;
end;
WriteSegyStructure(outfile,SegyHeader,SegyTraceHeader,seisdata,'revision',Revision,'dsf',DSF);
status=fclose('all');

%________________________________   FINAL INFO DISPLAY  

disp '*******************************************************';
disp(cc24);disp(cc25);disp(cc27); 
disp([outfile ' CREATED']);
disp '*******************************************************';
button = questdlg('Close All Figures and Clear Workspace','Image converted to SEGY','Yes','No','Yes');
if strcmp(button,'Yes'); close all; clear all; end
disp ('No errors end'); 
%___________________________________________END           
